ZorroParser
===========

A parser for categorizing TDD development episodes using Zorro heuristics