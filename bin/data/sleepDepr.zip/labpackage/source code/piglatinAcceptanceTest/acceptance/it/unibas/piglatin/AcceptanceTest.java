package it.unibas.piglatin;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ US1Test.class, US2Test.class, US3Test.class, US4Test.class, US5Test.class,
		US6Test.class, US7Test.class, US8Test.class})
public class AcceptanceTest {
}