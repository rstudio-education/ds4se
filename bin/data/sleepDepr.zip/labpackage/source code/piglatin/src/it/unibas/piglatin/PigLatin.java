package it.unibas.piglatin;

public class PigLatin {

	public PigLatin(String string) {
		// TODO Auto-generated method stub
	}
	
	public String phrase(){
		// TODO Auto-generated method stub
		return null;
	}
	
	public String translate(){
		// TODO Auto-generated method stub
		return null;
	}
	

}
