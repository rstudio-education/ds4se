package piglatin;

import static org.junit.Assert.*;

import org.junit.Test;

public class PigLatinTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
